#!/bin/bash
vmd sars_clean_out.pdb -e sars_clean.tcl
