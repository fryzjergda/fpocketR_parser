#!/bin/bash
pymol sars_clean.pml
